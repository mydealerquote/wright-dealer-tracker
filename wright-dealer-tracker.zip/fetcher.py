from typing import List, Dict

def fetch_dealers_near(lat: float, lng: float) -> List[Dict]:
    # TODO: Implement real API call after inspecting dealer locator endpoint.
    return []
